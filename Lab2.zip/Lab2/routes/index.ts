﻿/*
 * GET home page.
 */
import express = require('express');
const router = express.Router();

router.get('/', (req: express.Request, res: express.Response) => {
    var method = req.query.method;
    var x = parseInt(req.query.x);
    var y = parseInt(req.query.y);

    if (method == 'add') {
        res.send('x + y = ' + (x + y).toString());
    }

    else if (method == 'subtract') {
        res.send('x - y = ' + (x - y).toString());
    }

    else if (method == 'multiply') {
        res.send('x * y = ' + (x * y).toString());
    }

    else if (method == 'divide') {
        res.send('x / y = ' + (x / y).toString());
    }

    else{
         res.send('Error; basic arithmetic math method required.');
    }

});

export default router;