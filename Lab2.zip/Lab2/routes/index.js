"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * GET home page.
 */
var express = require("express");
var router = express.Router();
router.get('/', function (req, res) {
    var method = req.query.method;
    var x = parseInt(req.query.x);
    var y = parseInt(req.query.y);
    if (method == 'add') {
        res.send('x + y = ' + (x + y).toString());
    }
    else if (method == 'subtract') {
        res.send('x - y = ' + (x - y).toString());
    }
    else if (method == 'multiply') {
        res.send('x * y = ' + (x * y).toString());
    }
    else if (method == 'divide') {
        res.send('x / y = ' + (x / y).toString());
    }
    else {
        res.send('Error; basic arithmetic math method required.');
    }
});
exports.default = router;
//# sourceMappingURL=index.js.map